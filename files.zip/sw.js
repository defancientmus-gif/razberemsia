// Разберёмся — Service Worker v2.0
const CACHE = 'razberemsia-v2';
const ASSETS = [
  '/razberemsia/razberemsia_v03.html',
  '/razberemsia/manifest.json'
];

// ── Установка ──
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE).then(cache => cache.addAll(ASSETS))
  );
  self.skipWaiting();
});

// ── Активация ──
self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
    )
  );
  self.clients.claim();
  // Запускаем проверку каждую минуту
  startPeriodicCheck();
});

// ── Запросы ──
self.addEventListener('fetch', e => {
  e.respondWith(
    fetch(e.request).catch(() => caches.match(e.request))
  );
});

// ── Получение заметок от приложения ──
let scheduledNotes = [];

self.addEventListener('message', e => {
  if (e.data?.type === 'SCHEDULE') {
    scheduledNotes = e.data.notes || [];
    checkReminders();
  }
});

// ── Проверка каждую минуту ──
function startPeriodicCheck() {
  setInterval(() => checkReminders(), 60000);
}

function checkReminders() {
  const now = new Date();
  const nowY = now.getFullYear();
  const nowM = now.getMonth();
  const nowD = now.getDate();
  const nowH = now.getHours();
  const nowMin = now.getMinutes();

  scheduledNotes.forEach(n => {
    if (!n.reminder) return;
    // Парсим как локальное время
    const parts = n.reminder.match(/(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/);
    if (!parts) return;
    const rY = parseInt(parts[1]);
    const rM = parseInt(parts[2]) - 1;
    const rD = parseInt(parts[3]);
    const rH = parseInt(parts[4]);
    const rMin = parseInt(parts[5]);

    // Совпадает ли текущая минута с напоминанием
    if (rY===nowY && rM===nowM && rD===nowD && rH===nowH && rMin===nowMin) {
      self.registration.showNotification('Разберёмся', {
        body: n.title || 'Напоминание',
        icon: '/razberemsia/icon-192.png',
        badge: '/razberemsia/icon-192.png',
        vibrate: [300, 100, 300],
        tag: 'reminder-' + n.title,
        renotify: true,
        data: { url: '/razberemsia/razberemsia_v03.html?action=notes' }
      });
    }
  });
}

// ── Клик по уведомлению ──
self.addEventListener('notificationclick', e => {
  e.notification.close();
  const url = e.notification.data?.url || '/razberemsia/razberemsia_v03.html';
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(list => {
      for (const client of list) {
        if (client.url.includes('razberemsia') && 'focus' in client)
          return client.focus();
      }
      return clients.openWindow(url);
    })
  );
});

// ── Push от сервера (будущее) ──
self.addEventListener('push', e => {
  const data = e.data ? e.data.json() : {};
  e.waitUntil(
    self.registration.showNotification(data.title || 'Разберёмся', {
      body: data.body || 'Новое напоминание',
      icon: '/razberemsia/icon-192.png',
      vibrate: [300, 100, 300],
      data: { url: data.url || '/razberemsia/razberemsia_v03.html' }
    })
  );
});
